// Adam Tyton

#include "garden.hpp"

#define NULL 0


unsigned int GARDEN_CLASS::getTreesTotal() {
    return 0;
}
unsigned int GARDEN_CLASS::getBranchesTotal()
{
    return 0;
}
unsigned int GARDEN_CLASS::getFruitsTotal()
{
    return 0;
}
unsigned int GARDEN_CLASS::getWeightsTotal ()
{
    return 0;
}


TREE_CLASS* GARDEN_CLASS::getTreePointer (unsigned int treeID)
{
    return 0;
}

// ------- SETTERS -------

void GARDEN_CLASS::plantTree ()
{

}
void GARDEN_CLASS::extractTree (unsigned int treeID)
{

}
void GARDEN_CLASS::cloneTree (unsigned int treeID)
{

}

void GARDEN_CLASS::growthGarden ()
{

}
void GARDEN_CLASS::fadeGarden ()
{

}
void GARDEN_CLASS::harvestGarden ()
{

}

void GARDEN_CLASS::harvestGarden (int a)
{

}
